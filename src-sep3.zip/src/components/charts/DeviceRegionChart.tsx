import React, { useState } from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { BarChart3 } from 'lucide-react';
import { DeviceRegionStatsData } from '../../services/api';

interface DeviceRegionChartProps {
  title: string;
  data: DeviceRegionStatsData[];
  totalBookings: number;
}

export const DeviceRegionChart: React.FC<DeviceRegionChartProps> = ({ title, data, totalBookings }) => {
  const [chartType, setChartType] = useState<'stacked-bar' | 'simple-bar'>('stacked-bar');

  // Transform data for stacked bar chart
  const transformDataForStackedBar = () => {
    const regions = [...new Set(data.map(item => item.region))];
    const devices = [...new Set(data.map(item => item.device))];
    
    return regions.map(region => {
      const regionData: any = { region };
      devices.forEach(device => {
        const item = data.find(d => d.device === device && d.region === region);
        regionData[device] = item ? item.booking_count : 0;
      });
      return regionData;
    });
  };

  // Transform data for simple bar chart
  const transformDataForSimpleBar = () => {
    return data
      .sort((a, b) => b.booking_count - a.booking_count)
      .slice(0, 20) // Show top 20 combinations
      .map(item => ({
        name: `${item.device} - ${item.region}`,
        value: item.booking_count,
        color: item.color
      }));
  };

  const regions = [...new Set(data.map(item => item.region))];
  const devices = [...new Set(data.map(item => item.device))];

  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-white p-3 border border-gray-200 rounded-lg shadow-lg">
          <p className="font-semibold text-gray-900">{label}</p>
          {payload.map((entry: any, index: number) => (
            <p key={index} style={{ color: entry.color }} className="text-sm">
              {entry.name}: {entry.value.toLocaleString()} bookings
            </p>
          ))}
        </div>
      );
    }
    return null;
  };

  const renderChart = () => {
    switch (chartType) {
      case 'stacked-bar':
        return (
          <ResponsiveContainer width="100%" height={400}>
            <BarChart
              data={transformDataForStackedBar()}
              margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
            >
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis 
                dataKey="region" 
                tick={{ fontSize: 12 }}
                angle={-45}
                textAnchor="end"
                height={80}
              />
              <YAxis 
                tick={{ fontSize: 12 }}
                label={{ value: 'Bookings', angle: -90, position: 'insideLeft' }}
              />
              <Tooltip content={<CustomTooltip />} />
              <Legend />
              {devices.map((device) => (
                <Bar
                  key={device}
                  dataKey={device}
                  stackId="a"
                  fill={data.find(d => d.device === device)?.color || '#8884d8'}
                  name={device}
                />
              ))}
            </BarChart>
          </ResponsiveContainer>
        );

      case 'simple-bar':
        return (
          <ResponsiveContainer width="100%" height={400}>
            <BarChart
              data={transformDataForSimpleBar()}
              margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
            >
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis 
                dataKey="name" 
                tick={{ fontSize: 10 }}
                angle={-45}
                textAnchor="end"
                height={100}
              />
              <YAxis 
                tick={{ fontSize: 12 }}
                label={{ value: 'Bookings', angle: -90, position: 'insideLeft' }}
              />
              <Tooltip 
                content={({ active, payload, label }: any) => {
                  if (active && payload && payload.length) {
                    return (
                      <div className="bg-white p-3 border border-gray-200 rounded-lg shadow-lg">
                        <p className="font-semibold text-gray-900">{label}</p>
                        <p className="text-sm text-gray-600">
                          Bookings: {payload[0].value.toLocaleString()}
                        </p>
                      </div>
                    );
                  }
                  return null;
                }}
              />
              <Bar dataKey="value" fill="#10B981" />
            </BarChart>
          </ResponsiveContainer>
        );

      default:
        return null;
    }
  };

  return (
    <div className="shadow-xl border-0 bg-gradient-to-br from-white to-gray-50 overflow-hidden rounded-lg">
      <div className="bg-gradient-to-r from-green-600 to-emerald-600 text-white border-0 p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3 text-white">
            <div className="p-2 bg-white/20 rounded-lg backdrop-blur-sm">
              <BarChart3 className="w-5 h-5" />
            </div>
            <span className="text-xl font-bold">{title}</span>
          </div>
          
          {/* Chart Type Selector */}
          <div className="flex space-x-2">
            <button
              onClick={() => setChartType('stacked-bar')}
              className={`px-3 py-2 rounded-lg text-sm font-medium transition-colors ${
                chartType === 'stacked-bar'
                  ? 'bg-white text-green-600'
                  : 'bg-white/20 text-white hover:bg-white/30'
              }`}
            >
              <BarChart3 className="w-4 h-4 inline mr-1" />
              Stacked Bar
            </button>
            <button
              onClick={() => setChartType('simple-bar')}
              className={`px-3 py-2 rounded-lg text-sm font-medium transition-colors ${
                chartType === 'simple-bar'
                  ? 'bg-white text-green-600'
                  : 'bg-white/20 text-white hover:bg-white/30'
              }`}
            >
              <BarChart3 className="w-4 h-4 inline mr-1" />
              Simple Bar
            </button>
          </div>
        </div>
      </div>
      
      <div className="p-6">
        <div className="mb-4 text-center">
          <p className="text-2xl font-bold text-gray-900">{totalBookings.toLocaleString()}</p>
          <p className="text-gray-600">Total Bookings</p>
        </div>
        
        {renderChart()}
        
        <div className="mt-4 text-center text-sm text-gray-500">
          Showing device distribution across {regions.length} regions
        </div>
      </div>
    </div>
  );
}; 