import React from 'react';
import { BarChart as RechartsBarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from 'recharts';
import { Card, CardHeader, CardContent, CardTitle } from '../ui/Card';
import { Globe } from 'lucide-react';
import { CountryStatsData } from '../../services/api';

interface CountryChartProps {
  title: string;
  data: CountryStatsData[];
  totalBookings: number;
}

const CustomTooltip = ({ active, payload, label }: any) => {
  if (active && payload && payload.length) {
    const data = payload[0].payload;
    return (
      <div className="bg-white p-4 border-0 rounded-xl shadow-2xl backdrop-blur-sm border border-gray-100">
        <p className="text-sm font-bold text-gray-900 mb-2">{label}</p>
        <p className="text-sm font-medium flex items-center space-x-2" style={{ color: data.color }}>
          <span className="w-3 h-3 rounded-full" style={{ backgroundColor: data.color }}></span>
          <span>Bookings: {data.confirmed_bookings.toLocaleString()}</span>
        </p>
        <p className="text-sm font-medium text-gray-600">
          Percentage: {data.percentage.toFixed(1)}%
        </p>
      </div>
    );
  }
  return null;
};

export const CountryChart: React.FC<CountryChartProps> = ({ 
  title, 
  data, 
  totalBookings 
}) => {
  // Sort data by confirmed_bookings in descending order
  const sortedData = [...data].sort((a, b) => b.confirmed_bookings - a.confirmed_bookings);

  return (
    <Card className="shadow-xl border-0 bg-gradient-to-br from-white to-gray-50 overflow-hidden">
      <CardHeader className="bg-gradient-to-r from-blue-600 to-indigo-600 text-white border-0">
        <CardTitle className="flex items-center space-x-3 text-white">
          <div className="p-2 bg-white/20 rounded-lg backdrop-blur-sm">
            <Globe className="w-5 h-5" />
          </div>
          <span className="text-xl font-bold">{title}</span>
        </CardTitle>
      </CardHeader>
      <CardContent className="p-6">
        <div className="mb-4 text-center">
          <p className="text-2xl font-bold text-gray-900">{totalBookings.toLocaleString()}</p>
          <p className="text-sm text-gray-600">Total Bookings</p>
        </div>
        <div className="h-80 bg-white rounded-xl p-4 shadow-inner">
          <ResponsiveContainer width="100%" height="100%">
            <RechartsBarChart data={sortedData} margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" opacity={0.6} />
              <XAxis 
                dataKey="country" 
                axisLine={false}
                tickLine={false}
                tick={{ fontSize: 12, fill: '#6B7280', fontWeight: 500 }}
                angle={-45}
                textAnchor="end"
                height={80}
              />
              <YAxis 
                axisLine={false}
                tickLine={false}
                tick={{ fontSize: 12, fill: '#6B7280', fontWeight: 500 }}
                tickFormatter={(value) => value.toLocaleString()}
              />
              <Tooltip content={<CustomTooltip />} />
              <Bar 
                dataKey="confirmed_bookings" 
                radius={[8, 8, 0, 0]}
              >
                {sortedData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Bar>
            </RechartsBarChart>
          </ResponsiveContainer>
        </div>
      </CardContent>
    </Card>
  );
}; 