import React, { useState, useEffect } from 'react';
import { DateRangePicker } from './DateRangePicker';
import { StatsCard } from './StatsCard';
import { BarChart } from './charts/BarChart';
import { DonutChart } from './charts/DonutChart';
import { FunnelChart } from './charts/FunnelChart';
import { CountryChart } from './charts/CountryChart';
import BookingsByOS from './BookingsByOS';
import { DeviceRegionChart } from './charts/DeviceRegionChart';
import { apiService, ConversionRateData, DeviceStatsData, BrowserStatsData, BrowserStatsResponse, CountryStatsData, FunnelData, DailyStatsData, OSStatsResponse, IApiService } from '../services/api';
import { mockApiService } from '../services/mockApi';
import { 
  Users, 
  ShoppingCart, 
  TrendingUp,
  Target,
  Smartphone,
  Globe
} from 'lucide-react';

interface AnalyticsDashboardProps {
  startDate: string;
  endDate: string;
}

export const AnalyticsDashboard: React.FC<AnalyticsDashboardProps> = ({
  startDate,
  endDate
}) => {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  
  // State for all API data
  const [conversionData, setConversionData] = useState<ConversionRateData | null>(null);
  const [deviceStats, setDeviceStats] = useState<DeviceStatsData[]>([]);
  const [browserStats, setBrowserStats] = useState<BrowserStatsData[]>([]);
  const [countryStats, setCountryStats] = useState<CountryStatsData[]>([]);
  const [funnelData, setFunnelData] = useState<FunnelData | null>(null);
  const [dailyStats, setDailyStats] = useState<DailyStatsData[]>([]);
  const [osStats, setOsStats] = useState<OSStatsResponse | null>(null);
  const [totalCountryBookings, setTotalCountryBookings] = useState(0);
  const [deviceRegionData, setDeviceRegionData] = useState<any[]>([]);
  const [totalDeviceRegionBookings, setTotalDeviceRegionBookings] = useState(0);
  const [deviceRegionDataSource, setDeviceRegionDataSource] = useState<string | null>(null);

  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        setError(null);

        console.log('Starting to fetch data...');
        
        // Try real API first, fallback to mock API
        let service: IApiService = mockApiService;
        
        // Only test real API if we have valid dates
        if (startDate && endDate) {
          try {
            // Test if real API is available with a simple endpoint
            await apiService.getConversionRate({ start_date: startDate, end_date: endDate });
            console.log('✅ Real API detected - using live data');
            service = apiService;
          } catch (err) {
            console.log('⚠️ Real API not available - using mock data');
            service = mockApiService;
          }
        } else {
          console.log('⚠️ No date range selected - using mock data');
          service = mockApiService;
        }

        // Fetch all data using the user-selected date range
        const [
          conversionResult,
          deviceResult,
          browserResult,
          countryResult,
          funnelResult,
          dailyResult,
          osResult,
          deviceRegionResult
        ] = await Promise.all([
          // Conversion Rate API - supports both single date and date range
          service.getConversionRate({ 
            start_date: startDate, 
            end_date: endDate
          }),
          
          // Device Stats API - requires start_date and end_date
          service.getDeviceStats({ 
            start_date: startDate, 
            end_date: endDate 
          }),
          
          // Browser Stats API - use date for single date, start_date/end_date for range
          service.getBrowserStats({ 
            date: startDate === endDate ? startDate : undefined,
            start_date: startDate !== endDate ? startDate : undefined,
            end_date: startDate !== endDate ? endDate : undefined
          }),
          
          // Country Stats API - requires start_date and end_date
          service.getCountryStats({ 
            start_date: startDate, 
            end_date: endDate 
          }),
          
          // Funnel API - requires start_date and end_date
          service.getFunnel({ 
            start_date: startDate, 
            end_date: endDate 
          }),
          
          // Daily Stats API - requires start_date and end_date
          service.getDailyStats({ 
            start_date: startDate, 
            end_date: endDate 
          }),

          // OS Stats Combined API - requires start_date and end_date
          service.getOSStatsCombined({
            start_date: startDate,
            end_date: endDate
          }),

          // Device Region API - requires start_date and end_date
          service.getDeviceRegionStats({
            start_date: startDate,
            end_date: endDate
          })
        ]);

        console.log('Data fetched successfully:', {
          conversionResult,
          deviceResult,
          browserResult,
          countryResult,
          funnelResult,
          dailyResult,
          osResult,
          deviceRegionResult
        });

        setConversionData(conversionResult);
        setDeviceStats(deviceResult.device_stats);
        
        // Browser stats API returns different formats:
        // - Single date: array directly [{...}, {...}]
        // - Date range: object with browser_stats property {browser_stats: [{...}, {...}]}
        const browserStatsData = Array.isArray(browserResult) 
          ? browserResult 
          : (browserResult as BrowserStatsResponse).browser_stats || [];
        setBrowserStats(browserStatsData);
        
        setCountryStats(countryResult.country_stats);
        setTotalCountryBookings(countryResult.total_confirmed_bookings);
        setFunnelData(funnelResult);
        setDailyStats(dailyResult.daily_stats);
        setOsStats(osResult);
        setDeviceRegionData(deviceRegionResult.device_region_stats);
        setTotalDeviceRegionBookings(deviceRegionResult.total_confirmed_bookings);
        setDeviceRegionDataSource(deviceRegionResult.source);

        console.log('State updated successfully');
      } catch (err) {
        console.error('Error fetching data:', err);
        setError(err instanceof Error ? err.message : 'Failed to fetch data');
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [startDate, endDate]);

  console.log('AnalyticsDashboard render state:', {
    loading,
    error,
    conversionData,
    deviceStats: deviceStats.length,
    browserStats: browserStats.length,
    countryStats: countryStats.length,
    funnelData,
    dailyStats: dailyStats.length,
    osStats: osStats ? 'loaded' : 'not loaded',
    deviceRegionData: deviceRegionData.length,
    totalDeviceRegionBookings: totalDeviceRegionBookings
  });

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Loading analytics data...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-center">
          <p className="text-red-600 mb-2">Error loading data</p>
          <p className="text-gray-600 text-sm">{error}</p>
        </div>
      </div>
    );
  }

  // Transform data for charts
  const deviceChartData = deviceStats.map(stat => ({
    name: stat.device,
    value: stat.confirmed_bookings,
    color: stat.color
  }));

  const browserChartData = browserStats.map((stat, index) => {
    const colors = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884D8', '#82CA9D', '#FFC658'];
    return {
      name: stat.browser,
      value: stat.confirmed_bookings,
      color: colors[index % colors.length]
    };
  });

  const dailyChartData = dailyStats.map(stat => ({
    name: new Date(stat.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
    value: stat.confirmed_bookings,
    previous: stat.total_visitors
  }));

  const funnelChartData = funnelData?.funnel_steps.map(step => ({
    name: step.step,
    value: step.value,
    color: step.color,
    icon: step.step === 'Total Visitors' ? <Users className="w-4 h-4" /> :
          step.step === 'Confirmed Bookings' ? <ShoppingCart className="w-4 h-4" /> :
          <Target className="w-4 h-4" />
  })) || [];

  console.log('Rendering dashboard with data:', {
    conversionData,
    deviceStats,
    browserStats,
    countryStats,
    funnelData,
    dailyStats,
    deviceChartData,
    browserChartData,
    dailyChartData,
    funnelChartData,
    deviceRegionData: deviceRegionData.length,
    totalDeviceRegionBookings: totalDeviceRegionBookings
  });

  return (
    <div className="space-y-8">


      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatsCard
          title="Conversion Rate"
          value={`${conversionData?.booking_conversion_rate?.toFixed(2) || '0'}%`}
          change="12.5%"
          changeType="positive"
          icon={TrendingUp}
          iconColor="text-green-600"
          iconBg="bg-green-100"
        />
        <StatsCard
          title="Total Bookings"
          value={conversionData?.confirmed_bookings?.toLocaleString() || '0'}
          change="8.2%"
          changeType="positive"
          icon={ShoppingCart}
          iconColor="text-blue-600"
          iconBg="bg-blue-100"
        />
        <StatsCard
          title="Total Visitors"
          value={conversionData?.total_visitors?.toLocaleString() || '0'}
          change="3.1%"
          changeType="positive"
          icon={Users}
          iconColor="text-purple-600"
          iconBg="bg-purple-100"
        />
        <StatsCard
          title="Drop-off Rate"
          value={funnelData?.total_visitors && funnelData.total_visitors > 0 
            ? `${funnelData.dropoff_rate?.toFixed(1) || '0'}%` 
            : 'N/A'}
          change="2.4%"
          changeType="negative"
          icon={Target}
          iconColor="text-orange-600"
          iconBg="bg-orange-100"
        />
      </div>

      {/* Charts Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <CountryChart 
          title="Bookings by Country" 
          data={countryStats}
          totalBookings={totalCountryBookings}
        />
        <BookingsByOS osStats={osStats} loading={loading} />
      </div>

      {/* Device and Browser Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <DonutChart 
          title="Bookings by Device" 
          data={deviceChartData}
        />
        <DonutChart 
          title="Bookings by Browser" 
          data={browserChartData}
        />
      </div>

      {/* Conversion Funnel */}
      <div>
        {funnelData?.total_visitors && funnelData.total_visitors > 0 ? (
          <FunnelChart 
            title="Booking Conversion Funnel" 
            data={funnelChartData}
            showConversionRates={true}
          />
        ) : (
          <div className="bg-white rounded-lg shadow p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Booking Conversion Funnel</h3>
            <div className="flex items-center justify-center h-32 text-gray-500">
              <div className="text-center">
                <p className="text-sm">Funnel data not available for selected date range</p>
                <p className="text-xs mt-1">Try July 31st for funnel analytics</p>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Device Performance Bar Chart */}
      <div>
        <BarChart 
          title="Device Performance Comparison" 
          data={deviceStats.map(stat => ({
            name: stat.device,
            value: stat.confirmed_bookings
          }))} 
          color="#10B981"
        />
      </div>

      {/* Device Region Analytics Section */}
      <div className="bg-white rounded-lg shadow-lg p-6 mb-8">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center space-x-3">
            <div className="p-2 bg-gradient-to-r from-green-500 to-emerald-500 rounded-lg">
              <Globe className="w-6 h-6 text-white" />
            </div>
            <div>
              <h2 className="text-2xl font-bold text-gray-900">Device Region Analytics</h2>
              <p className="text-gray-600">Device distribution across different regions</p>
            </div>
          </div>
        </div>

        {/* Device Region Chart */}
        <div className="mb-6">
          <DeviceRegionChart
            title="Device Distribution by Region"
            data={deviceRegionData}
            totalBookings={totalDeviceRegionBookings}
          />
        </div>

        {/* Summary Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
          <div className="bg-gradient-to-r from-blue-50 to-blue-100 p-4 rounded-lg border border-blue-200">
            <div className="flex items-center space-x-3">
              <div className="p-2 bg-blue-500 rounded-lg">
                <Globe className="w-4 h-4 text-white" />
              </div>
              <div>
                <p className="text-sm text-blue-600 font-medium">Total Regions</p>
                <p className="text-2xl font-bold text-blue-900">
                  {deviceRegionData.length > 0 ? [...new Set(deviceRegionData.map(item => item.region))].length : 0}
                </p>
              </div>
            </div>
          </div>

          <div className="bg-gradient-to-r from-green-50 to-green-100 p-4 rounded-lg border border-green-200">
            <div className="flex items-center space-x-3">
              <div className="p-2 bg-green-500 rounded-lg">
                <Smartphone className="w-4 h-4 text-white" />
              </div>
              <div>
                <p className="text-sm text-green-600 font-medium">Total Devices</p>
                <p className="text-2xl font-bold text-green-900">
                  {deviceRegionData.length > 0 ? [...new Set(deviceRegionData.map(item => item.device))].length : 0}
                </p>
              </div>
            </div>
          </div>

          <div className="bg-gradient-to-r from-purple-50 to-purple-100 p-4 rounded-lg border border-purple-200">
            <div className="flex items-center space-x-3">
              <div className="p-2 bg-purple-500 rounded-lg">
                <ShoppingCart className="w-4 h-4 text-white" />
              </div>
              <div>
                <p className="text-sm text-purple-600 font-medium">Total Bookings</p>
                <p className="text-2xl font-bold text-purple-900">
                  {totalDeviceRegionBookings.toLocaleString()}
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Detailed Data Table */}
        <div className="bg-gray-50 rounded-lg p-4">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Detailed Breakdown</h3>
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-100">
                <tr>
                  <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Device
                  </th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Region
                  </th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Bookings
                  </th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Percentage
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {deviceRegionData
                  .sort((a, b) => b.booking_count - a.booking_count)
                  .map((item, index) => (
                    <tr key={index} className="hover:bg-gray-50">
                      <td className="px-4 py-3 whitespace-nowrap">
                        <div className="flex items-center space-x-2">
                          <div 
                            className="w-3 h-3 rounded-full" 
                            style={{ backgroundColor: item.color }}
                          />
                          <span className="text-sm font-medium text-gray-900">
                            {item.device}
                          </span>
                        </div>
                      </td>
                      <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-900">
                        {item.region}
                      </td>
                      <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-900">
                        {item.booking_count.toLocaleString()}
                      </td>
                      <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-900">
                        {item.percentage}%
                      </td>
                    </tr>
                  ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}; 