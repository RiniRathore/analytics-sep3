const BASE_URL = 'http://localhost:5000/api';

export interface ConversionRateData {
  booking_conversion_rate: number;
  confirmed_bookings: number;
  total_visitors: number;
  date?: string;
  start_date?: string;
  end_date?: string;
  propertyid?: string;
}

export interface DeviceShareData {
  device: string;
  confirmed_bookings: number;
}

export interface BrowserStatsData {
  browser: string;
  confirmed_bookings: number;
  percentage?: number;
  color?: string;
}

export interface BrowserStatsResponse {
  browser_stats: BrowserStatsData[];
  total_confirmed_bookings?: number;
  start_date?: string;
  end_date?: string;
  propertyid?: string;
}

export interface CountryStatsData {
  country: string;
  confirmed_bookings: number;
  percentage: number;
  color: string;
}

export interface DeviceStatsData {
  device: string;
  confirmed_bookings: number;
  percentage: number;
  color: string;
}

export interface DeviceCountryData {
  country: string;
  device: string;
  booking_count: number;
}

export interface BrowserCountryData {
  country: string;
  browser: string;
  booking_count: number;
}

export interface BookingTrendData {
  date: string;
  device?: string;
  browser?: string;
  country?: string;
  count: number;
}

export interface FunnelData {
  total_visitors: number;
  confirmed_bookings: number;
  conversion_rate: number;
  total_dropoff: number;
  dropoff_rate: number;
  start_date: string;
  end_date: string;
  funnel_steps: Array<{
    step: string;
    value: number;
    percentage: number;
    color: string;
  }>;
}

export interface DailyStatsData {
  date: string;
  total_visitors: number;
  confirmed_bookings: number;
}

export interface OSStatsData {
  os: string;
  confirmed_bookings: number;
  percentage?: number;
  color?: string;
}

export interface OSStatsResponse {
  os_stats: OSStatsData[];
  total_confirmed_bookings: number;
  start_date: string;
  end_date: string;
  source: string;
}

export interface DeviceRegionStatsData {
  device: string;
  region: string;
  booking_count: number;
  percentage: number;
  color: string;
}

export interface DeviceRegionStatsResponse {
  device_region_stats: DeviceRegionStatsData[];
  total_confirmed_bookings: number;
  start_date: string;
  end_date: string;
  source: string;
}


class ApiService {
  private async fetchApi<T>(endpoint: string, params?: Record<string, string>): Promise<T> {
    // Construct the full URL for relative paths
    const fullUrl = `${BASE_URL}${endpoint}`;
    
    // Build query string from params
    let queryString = '';
    if (params) {
      const searchParams = new URLSearchParams();
      Object.entries(params).forEach(([key, value]) => {
        if (value) searchParams.append(key, value);
      });
      queryString = searchParams.toString();
    }
    
    const url = queryString ? `${fullUrl}?${queryString}` : fullUrl;

    const response = await fetch(url);
    if (!response.ok) {
      throw new Error(`API request failed: ${response.statusText}`);
    }
    return response.json();
  }

  // Conversion Rate API
  async getConversionRate(params?: {
    date?: string;
    start_date?: string;
    end_date?: string;
    propertyid?: string;
  }): Promise<ConversionRateData> {
    return this.fetchApi<ConversionRateData>('/conversion_rate', params);
  }

  // Device Share API
  async getDeviceShare(params?: {
    date?: string;
    start_date?: string;
    end_date?: string;
    propertyid?: string;
  }): Promise<DeviceShareData[]> {
    return this.fetchApi<DeviceShareData[]>('/device_share', params);
  }

  // Browser Stats API
  async getBrowserStats(params?: {
    date?: string;
    start_date?: string;
    end_date?: string;
    propertyid?: string;
  }): Promise<BrowserStatsData[] | BrowserStatsResponse> {
    return this.fetchApi<BrowserStatsData[] | BrowserStatsResponse>('/browser_stats', params);
  }

  // Country Stats API
  async getCountryStats(params: {
    start_date: string;
    end_date: string;
  }): Promise<{ country_stats: CountryStatsData[]; total_confirmed_bookings: number }> {
    return this.fetchApi('/country_stats', params);
  }

  // Device Stats API
  async getDeviceStats(params: {
    start_date: string;
    end_date: string;
  }): Promise<{ device_stats: DeviceStatsData[]; total_confirmed_bookings: number }> {
    return this.fetchApi('/device_stats', params);
  }

  // Device Country Stats API
  async getDeviceCountryStats(params?: {
    date?: string;
    start_date?: string;
    end_date?: string;
    propertyid?: string;
  }): Promise<DeviceCountryData[]> {
    return this.fetchApi<DeviceCountryData[]>('/device_country_stats', params);
  }

  // Browser Country Stats API
  async getBrowserCountryStats(params?: {
    date?: string;
    start_date?: string;
    end_date?: string;
    propertyid?: string;
  }): Promise<BrowserCountryData[]> {
    return this.fetchApi<BrowserCountryData[]>('/browser_country_stats', params);
  }

  // Booking Trend API
  async getBookingTrend(params: {
    start_date: string;
    end_date: string;
    device?: string;
    browser?: string;
    country?: string;
  }): Promise<BookingTrendData[]> {
    return this.fetchApi<BookingTrendData[]>('/booking_trend', params);
  }

  // Funnel API
  async getFunnel(params: {
    start_date: string;
    end_date: string;
    device?: string;
  }): Promise<FunnelData> {
    return this.fetchApi<FunnelData>('/funnel', params);
  }

  // Daily Stats API
  async getDailyStats(params: {
    start_date: string;
    end_date: string;
  }): Promise<{ daily_stats: DailyStatsData[]; total_visitors_period: number }> {
    return this.fetchApi('/daily_stats', params);
  }

  // OS Stats API
  async getOSStatsCombined(params: {
    start_date: string;
    end_date: string;
  }): Promise<OSStatsResponse> {
    return this.fetchApi<OSStatsResponse>('/os_stats', params);
  }

  // Device Region Stats API
  async getDeviceRegionStats(params: {
    start_date: string;
    end_date: string;
  }): Promise<DeviceRegionStatsResponse> {
    return this.fetchApi<DeviceRegionStatsResponse>('/device_region_stats', params);
  }


}

export const apiService = new ApiService();

// Common interface for API services
export interface IApiService {
  getConversionRate(params?: { date?: string; start_date?: string; end_date?: string; propertyid?: string }): Promise<ConversionRateData>;
  getDeviceShare(params?: { date?: string; start_date?: string; end_date?: string; propertyid?: string }): Promise<DeviceShareData[]>;
  getBrowserStats(params?: { date?: string; start_date?: string; end_date?: string; propertyid?: string }): Promise<BrowserStatsData[] | BrowserStatsResponse>;
  getCountryStats(params: { start_date: string; end_date: string }): Promise<{ country_stats: CountryStatsData[]; total_confirmed_bookings: number }>;
  getDeviceStats(params: { start_date: string; end_date: string }): Promise<{ device_stats: DeviceStatsData[]; total_confirmed_bookings: number }>;
  getDeviceCountryStats(params?: { date?: string; start_date?: string; end_date?: string; propertyid?: string }): Promise<DeviceCountryData[]>;
  getBrowserCountryStats(params?: { date?: string; start_date?: string; end_date?: string; propertyid?: string }): Promise<BrowserCountryData[]>;
  getBookingTrend(params: { start_date: string; end_date: string; device?: string; browser?: string; country?: string }): Promise<BookingTrendData[]>;
  getFunnel(params: { start_date: string; end_date: string; device?: string }): Promise<FunnelData>;
  getDailyStats(params: { start_date: string; end_date: string }): Promise<{ daily_stats: DailyStatsData[]; total_visitors_period: number }>;
  getOSStatsCombined(params: { start_date: string; end_date: string }): Promise<OSStatsResponse>;
  getDeviceRegionStats(params: { start_date: string; end_date: string }): Promise<DeviceRegionStatsResponse>;

} 