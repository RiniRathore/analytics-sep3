// Mock API service for demonstration purposes
// This simulates the real API responses when the backend is not available

export interface ConversionRateData {
  booking_conversion_rate: number;
  confirmed_bookings: number;
  total_visitors: number;
  date?: string;
  start_date?: string;
  end_date?: string;
  propertyid?: string;
}

export interface DeviceShareData {
  device: string;
  confirmed_bookings: number;
}

export interface BrowserStatsData {
  browser: string;
  confirmed_bookings: number;
  percentage?: number;
  color?: string;
}

export interface CountryStatsData {
  country: string;
  confirmed_bookings: number;
  percentage: number;
  color: string;
}

export interface DeviceStatsData {
  device: string;
  confirmed_bookings: number;
  percentage: number;
  color: string;
}

export interface DeviceCountryData {
  country: string;
  device: string;
  booking_count: number;
}

export interface BrowserCountryData {
  country: string;
  browser: string;
  booking_count: number;
}

export interface BookingTrendData {
  date: string;
  device?: string;
  browser?: string;
  country?: string;
  count: number;
}

export interface FunnelData {
  total_visitors: number;
  confirmed_bookings: number;
  conversion_rate: number;
  total_dropoff: number;
  dropoff_rate: number;
  start_date: string;
  end_date: string;
  funnel_steps: Array<{
    step: string;
    value: number;
    percentage: number;
    color: string;
  }>;
}

export interface DailyStatsData {
  date: string;
  total_visitors: number;
  confirmed_bookings: number;
}

export interface OSStatsData {
  os: string;
  confirmed_bookings: number;
  percentage?: number;
  color?: string;
}

export interface OSStatsResponse {
  os_stats: OSStatsData[];
  total_confirmed_bookings: number;
  start_date: string;
  end_date: string;
  source: string;
}

export interface DeviceRegionStatsData {
  device: string;
  region: string;
  booking_count: number;
  percentage: number;
  color: string;
}

export interface DeviceRegionStatsResponse {
  device_region_stats: DeviceRegionStatsData[];
  total_confirmed_bookings: number;
  start_date: string;
  end_date: string;
  source: string;
}


import { IApiService, BrowserStatsResponse } from './api';

class MockApiService implements IApiService {
  private delay(ms: number = 500): Promise<void> {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  // Conversion Rate API
  async getConversionRate(params?: {
    date?: string;
    start_date?: string;
    end_date?: string;
    propertyid?: string;
  }): Promise<ConversionRateData> {
    await this.delay();
    return {
      booking_conversion_rate: 0,
      confirmed_bookings: 0,
      total_visitors: 0,
      date: params?.date,
      start_date: params?.start_date,
      end_date: params?.end_date,
      propertyid: params?.propertyid || 'all'
    };
  }

  // Device Share API
  async getDeviceShare(_params?: {
    date?: string;
    start_date?: string;
    end_date?: string;
    propertyid?: string;
  }): Promise<DeviceShareData[]> {
    await this.delay();
    return [];
  }

  // Browser Stats API
  async getBrowserStats(_params?: {
    date?: string;
    start_date?: string;
    end_date?: string;
    propertyid?: string;
  }): Promise<BrowserStatsData[] | BrowserStatsResponse> {
    await this.delay();
    return [];
  }

  // Country Stats API
  async getCountryStats(_params: {
    start_date: string;
    end_date: string;
  }): Promise<{ country_stats: CountryStatsData[]; total_confirmed_bookings: number }> {
    await this.delay();
    return {
      country_stats: [],
      total_confirmed_bookings: 0
    };
  }

  // Device Stats API
  async getDeviceStats(_params: {
    start_date: string;
    end_date: string;
  }): Promise<{ device_stats: DeviceStatsData[]; total_confirmed_bookings: number }> {
    await this.delay();
    return {
      device_stats: [],
      total_confirmed_bookings: 0
    };
  }

  // Device Country Stats API
  async getDeviceCountryStats(_params?: {
    date?: string;
    start_date?: string;
    end_date?: string;
    propertyid?: string;
  }): Promise<DeviceCountryData[]> {
    await this.delay();
    return [];
  }

  // Browser Country Stats API
  async getBrowserCountryStats(_params?: {
    date?: string;
    start_date?: string;
    end_date?: string;
    propertyid?: string;
  }): Promise<BrowserCountryData[]> {
    await this.delay();
    return [];
  }

  // Booking Trend API
  async getBookingTrend(_params: {
    start_date: string;
    end_date: string;
    device?: string;
    browser?: string;
    country?: string;
  }): Promise<BookingTrendData[]> {
    await this.delay();
    return [];
  }

  // Funnel API
  async getFunnel(params: {
    start_date: string;
    end_date: string;
    device?: string;
  }): Promise<FunnelData> {
    await this.delay();
    return {
      total_visitors: 0,
      confirmed_bookings: 0,
      conversion_rate: 0,
      total_dropoff: 0,
      dropoff_rate: 0,
      start_date: params.start_date,
      end_date: params.end_date,
      funnel_steps: []
    };
  }

  // Daily Stats API
  async getDailyStats(_params: {
    start_date: string;
    end_date: string;
  }): Promise<{ daily_stats: DailyStatsData[]; total_visitors_period: number }> {
    await this.delay();
    return {
      daily_stats: [],
      total_visitors_period: 0
    };
  }

  // OS Stats Combined API
  async getOSStatsCombined(params: {
    start_date: string;
    end_date: string;
  }): Promise<OSStatsResponse> {
    await this.delay();
    return {
      os_stats: [],
      total_confirmed_bookings: 0,
      start_date: params.start_date,
      end_date: params.end_date,
      source: "mock"
    };
  }

  // Device Region Stats API
  async getDeviceRegionStats(params: {
    start_date: string;
    end_date: string;
  }): Promise<DeviceRegionStatsResponse> {
    await this.delay();
    return {
      device_region_stats: [
        {
          device: "DESKTOP",
          region: "Europe",
          booking_count: 64,
          percentage: 15.2,
          color: "#0088FE"
        },
        {
          device: "ANDROID",
          region: "APAC",
          booking_count: 259,
          percentage: 61.4,
          color: "#00C49F"
        },
        {
          device: "IPHONE",
          region: "Oceania",
          booking_count: 98,
          percentage: 23.2,
          color: "#FFBB28"
        }
      ],
      total_confirmed_bookings: 421,
      start_date: params.start_date,
      end_date: params.end_date,
      source: "mock"
    };
  }

}

export const mockApiService = new MockApiService(); 